---
name: Premium Thai Feline Boutique
colors:
  surface: '#fcf8fb'
  surface-dim: '#dcd9dc'
  surface-bright: '#fcf8fb'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3f5'
  surface-container: '#f0edef'
  surface-container-high: '#eae7ea'
  surface-container-highest: '#e4e2e4'
  on-surface: '#1b1b1d'
  on-surface-variant: '#5c403b'
  inverse-surface: '#303032'
  inverse-on-surface: '#f3f0f2'
  outline: '#906f6a'
  outline-variant: '#e5bdb7'
  surface-tint: '#bc140d'
  primary: '#b50c08'
  on-primary: '#ffffff'
  primary-container: '#d92d20'
  on-primary-container: '#fff6f5'
  inverse-primary: '#ffb4a8'
  secondary: '#006e2b'
  on-secondary: '#ffffff'
  secondary-container: '#5efd83'
  on-secondary-container: '#00722d'
  tertiary: '#af1f15'
  on-tertiary: '#ffffff'
  tertiary-container: '#d2392a'
  on-tertiary-container: '#fff6f5'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#ffdad5'
  primary-fixed-dim: '#ffb4a8'
  on-primary-fixed: '#410000'
  on-primary-fixed-variant: '#930002'
  secondary-fixed: '#69ff89'
  secondary-fixed-dim: '#3ee26c'
  on-secondary-fixed: '#002108'
  on-secondary-fixed-variant: '#00531f'
  tertiary-fixed: '#ffdad5'
  tertiary-fixed-dim: '#ffb4a8'
  on-tertiary-fixed: '#410000'
  on-tertiary-fixed-variant: '#930303'
  background: '#fcf8fb'
  on-background: '#1b1b1d'
  surface-variant: '#e4e2e4'
typography:
  display-hero:
    fontFamily: IBM Plex Sans Thai
    fontSize: 56px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  display-hero-mobile:
    fontFamily: IBM Plex Sans Thai
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.2'
  section-title:
    fontFamily: IBM Plex Sans Thai
    fontSize: 36px
    fontWeight: '700'
    lineHeight: '1.3'
  section-title-mobile:
    fontFamily: IBM Plex Sans Thai
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.3'
  card-heading:
    fontFamily: IBM Plex Sans Thai
    fontSize: 22px
    fontWeight: '600'
    lineHeight: '1.4'
  body-main:
    fontFamily: Noto Sans Thai
    fontSize: 17px
    fontWeight: '400'
    lineHeight: '1.7'
  label-sm:
    fontFamily: Noto Sans Thai
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.2'
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-max: 1280px
  section-gap-lg: 120px
  section-gap-md: 80px
  gutter: 24px
  margin-mobile: 16px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style

The design system is anchored in a philosophy of **Sophisticated Warmth**. It balances the premium nature of high-end cat products with a welcoming, community-focused Thai retail experience. The visual language avoids the cluttered, high-density aesthetics of traditional marketplaces in favor of a **Minimalist-Corporate** hybrid style.

The goal is to evoke trust and reliability. By utilizing expansive whitespace, crisp borders, and a disciplined color application, the UI directs focus toward high-quality product photography. The emotional response should be one of "expert care"—professional enough for medical-grade supplies, yet friendly enough for boutique lifestyle accessories.

## Colors

This design system uses a high-contrast palette optimized for legibility and conversion. 

- **Primary Red (#D92D20)**: Reserved for primary actions, critical brand touchpoints, and active navigational states.
- **Dark Red (#B42318)**: Used for hover states on primary elements to provide depth without losing brand identity.
- **Soft Red (#FEF3F2)**: Applied to large surface areas or subtle highlights to soften the interface and maintain the "approachable" brand pillar.
- **LINE Green (#06C755)**: A functional color used strictly for LINE official account conversions and social sharing, ensuring immediate recognition for the Thai market.
- **Neutrals**: The background utilizes a warm-tinted off-white to reduce eye strain, while the text uses a deep onyx for maximum contrast in Thai glyph readability.

## Typography

The typography strategy prioritizes the structural complexity of the Thai script. By utilizing **IBM Plex Sans Thai** for headings, the system gains a modern, engineered feel that communicates authority. **Noto Sans Thai** is used for body copy due to its exceptional legibility at smaller sizes and its neutral character.

A generous line height of 1.7 is strictly enforced for body text to prevent "stacking" of Thai vowel and tone marks, ensuring a comfortable reading rhythm. All display type uses tighter tracking to maintain a premium, editorial look.

## Layout & Spacing

The layout follows a **Fixed Grid** philosophy for desktop to maintain a premium, curated feel. On screens wider than 1280px, the content sits centered with wide margins to emphasize the minimalist aesthetic.

- **Vertical Rhythm**: Massive vertical gaps (80px to 120px) are used between major sections to let the content breathe and prevent the "marketplace" visual density.
- **Grid**: A 12-column grid is used for desktop with 24px gutters. For mobile, a single-column stack is preferred with 16px side margins.
- **Internal Spacing**: Consistent increments of 8px (base unit) drive the padding within cards and components.

## Elevation & Depth

This design system uses a **Low-Contrast Outline** approach combined with **Ambient Shadows**. Depth is used sparingly to denote interactivity rather than structural complexity.

- **Level 0 (Base)**: Background (#FFFBFA). Flat.
- **Level 1 (Cards/Surfaces)**: White surface with a 1px border (#E8E4E3). No shadow or a very faint, 4% opacity neutral shadow (0px 2px 4px).
- **Level 2 (Hover/Active)**: When a card or button is hovered, the shadow expands to 12% opacity with a larger blur (0px 8px 16px) to simulate the object lifting toward the user.
- **Overlays**: Modals and dropdowns use a sharp 1px border and a medium-diffused shadow to separate them from the content layer.

## Shapes

The shape language is defined by **Soft Geometric** forms. A base radius of 8px to 12px is used to strike a balance between professional precision and friendly accessibility.

- **Standard Elements**: Buttons and Input fields use an 8px radius.
- **Containers**: Product cards and content blocks use a 12px radius.
- **Icons**: Icons should feature slightly rounded ends (2px cap) to match the component corner radius.

## Components

### Buttons
- **Primary**: Solid #D92D20 with white text. 8px radius. High-padding (12px 24px).
- **Secondary/LINE**: Solid #06C755 with white text. Used exclusively for "Chat with us" or LINE-specific actions.
- **Ghost**: Transparent background with #D92D20 border and text.

### Cards
- **Product Cards**: White background, 12px radius, 1px #E8E4E3 border. Use high-quality imagery that fills the top half of the card. Text is left-aligned with ample padding (20px).

### Input Fields
- **Text Inputs**: 1px #E8E4E3 border, 8px radius. On focus, the border changes to Primary Red (#D92D20) with a faint red outer glow. Labels are always placed above the input field for clarity.

### Lists & Navigation
- **Header**: Sticky navigation with a white background and a subtle bottom border. No heavy shadows.
- **Category Chips**: Pill-shaped with a #FEF3F2 background and #D92D20 text for "Selected" states; #FFFFFF with #E8E4E3 border for "Unselected" states.

### Checkboxes & Radios
- Uses the Primary Red for active states. Checkbox icons are simplified to 2pt strokes for a clean, technical look.